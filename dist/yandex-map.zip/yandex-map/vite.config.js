import path from 'node:path';

import legacy from '@vitejs/plugin-legacy';
import { defineConfig } from 'vite';

export default defineConfig({
    plugins: [
        legacy({
            targets: ['last 2 versions and not dead'],
        }),
    ],
    resolve: {
        extensions: ['.js'],
        alias: {
            '@': path.resolve(__dirname, 'src'),
        },
    },
    build: {
        target: 'es2015',
        minify: 'terser',
        cssMinify: 'lightningcss',
    },
});
