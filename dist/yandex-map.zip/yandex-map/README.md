# Карта для «Сколково»

## 🎯 Deploy

- **NODEJS:** `^20`
- **NPM:** `^10`
- **Port:** `3000`

## 📜 NPM Scripts:

| Script                 | Description                          |
| ---------------------- | ------------------------------------ |
| `npm install / npm ci` | Установка модулей                    |
| `npm run build`        | Запуск билда                         |
| `npm run dev`          | Запуск dev сборки                    |
| `npm run preview`      | Запуск preview                       |
| `npm run check:lint`   | Проверка eslint                      |
| `npm run check:format` | Форматирование prettier              |
| `npm run check:all`    | Проверка всего в параллельном режиме |

[Таблица с данными](https://docs.google.com/spreadsheets/d/1uT2TcAlyVyjLQJImY5gpHbKEh2kl-s4mveIdWT-bDNw/edit?gid=0#gid=0)
