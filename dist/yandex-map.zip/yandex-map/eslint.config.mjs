import { defineConfig, globalIgnores } from 'eslint/config';
import prettier from 'eslint-plugin-prettier';
import jsxA11Y from 'eslint-plugin-jsx-a11y';
import _import from 'eslint-plugin-import';
import simpleImportSort from 'eslint-plugin-simple-import-sort';
import unusedImports from 'eslint-plugin-unused-imports';
// import xss from 'eslint-plugin-xss';
// import noSecrets from 'eslint-plugin-no-secrets';
// import sonarjs from 'eslint-plugin-sonarjs';
// import compat from 'eslint-plugin-compat';
import { fixupPluginRules } from '@eslint/compat';
import globals from 'globals';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import js from '@eslint/js';
import { FlatCompat } from '@eslint/eslintrc';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const flatCompat = new FlatCompat({
    baseDirectory: __dirname,
    recommendedConfig: js.configs.recommended,
    allConfig: js.configs.all,
});

export default defineConfig([
    globalIgnores(['**/node_modules/', './eslint.config.mjs']),
    {
        extends: flatCompat.extends(
            'eslint:recommended',
            'prettier',
            'plugin:jsx-a11y/recommended',
            // 'plugin:xss/recommended',
            // 'plugin:sonarjs/recommended-legacy',
            'plugin:compat/recommended'
        ),

        plugins: {
            prettier,
            // xss,
            // sonarjs,
            // compat,
            import: fixupPluginRules(_import),
            'jsx-a11y': jsxA11Y,
            'simple-import-sort': simpleImportSort,
            'unused-imports': unusedImports,
            // 'no-secrets': noSecrets,
        },

        languageOptions: {
            globals: {
                ...globals.browser,
                ...globals.node,
                window: true,
            },

            ecmaVersion: 2020,
            sourceType: 'module',
        },

        rules: {
            yoda: 'error',

            'prettier/prettier': 'error',

            // 'xss/no-mixed-html': [
            //     2,
            //     {
            //         functions: {
            //             sanitize: {
            //                 htmlOutput: true,
            //             },
            //         },
            //     },
            // ],

            // 'no-secrets/no-secrets': 'error',
            'no-unused-vars': 'off',
            'no-use-before-define': 'off',
            'no-underscore-dangle': 'off',
            'no-shadow': 'off',
            'class-methods-use-this': 'off',
            'no-alert': 'warn',
            'no-caller': 'error',
            'no-constructor-return': 'error',
            'no-eval': 'error',
            'no-nested-ternary': 'error',
            'no-extend-native': 'error',
            'no-multi-assign': ['error'],
            'no-implicit-coercion': 'error',
            'no-lonely-if': 'warn',
            'no-unneeded-ternary': 'error',

            'no-else-return': [
                'error',
                {
                    allowElseIf: false,
                },
            ],

            'prefer-object-spread': 'warn',
            'max-depth': ['error', 2],
            'consistent-return': ['error'],
            'no-implied-eval': 'error',
            'no-iterator': 'error',
            'no-labels': ['error'],
            'no-lone-blocks': 'error',
            'no-duplicate-imports': 'error',
            'no-empty-pattern': 'error',
            'no-new-func': 'error',
            'no-new-wrappers': 'error',
            'no-param-reassign': 'error',
            'no-proto': 'error',
            'no-return-assign': 'error',
            'no-script-url': 'error',
            'no-self-compare': 'error',
            'no-sequences': 'error',
            'no-useless-call': 'error',
            'no-useless-concat': 'error',
            'no-useless-return': 'warn',

            'no-console': [
                'warn',
                {
                    allow: ['error'],
                },
            ],

            'prefer-promise-reject-errors': [
                'error',
                {
                    allowEmptyReject: true,
                },
            ],

            'prefer-regex-literals': 'error',

            'no-magic-numbers': [
                'warn',
                {
                    ignoreArrayIndexes: true,
                    ignoreDefaultValues: true,
                    ignore: [-1, 0, 1, 2, 200, 400, 403, 404, 500],
                },
            ],

            'max-len': [
                2,
                {
                    code: 120,
                    ignoreUrls: true,
                },
            ],

            'import/extensions': 'off',
            'import/prefer-default-export': 'off',
            'import/no-cycle': 'off',

            'import/no-extraneous-dependencies': [
                'error',
                {
                    includeTypes: true,
                },
            ],

            'simple-import-sort/imports': 'warn',
            'simple-import-sort/exports': 'warn',
            'unused-imports/no-unused-imports': 'error',
            'unused-imports/no-unused-vars': 'off',
        },
    },
]);
