export function showConsoleError(error) {
    console.error(
        '%c YandexMap:',
        'color:#000;background-color:#b1ec52;border-radius:2px;padding:3px3px3px0;font-weight:bold;);',
        error
    );
}
