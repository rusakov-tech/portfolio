export function hideElement(element) {
    element.classList.add('sk-visually-hidden');
}
