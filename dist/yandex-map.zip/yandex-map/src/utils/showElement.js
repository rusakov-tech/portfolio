export function showElement(element) {
    element.classList.remove('sk-visually-hidden');
}
