import '@/styles/index.css';

import { ErrorMessage } from '@/components/core/ErrorMessage';
import { Map } from '@/components/features/Map';
import { Adapter } from '@/domain/Adapter';
import { categories } from '@/domain/map/categories';
import {
    MAP_API_KEY,
    MAP_BASE_PARAMS,
    MAP_CONTAINER_ID,
    MAP_LOADER_ID,
} from '@/domain/map/settings';
import { MapStore } from '@/domain/map/Store';
import { Parser } from '@/domain/Parser';
import { GoogleSheetsService } from '@/domain/services/GoogleSheets';
import { sheetColumns } from '@/domain/sheet/columns';
import { API_KEY_SHEETS, SHEET_ID } from '@/domain/sheet/settings';
import { hideElement } from '@/utils/hideElement';
import { showConsoleError } from '@/utils/showConsoleError';

function createInitialState() {
    window.map = null;
    window.objectManager = null;
    window.activeObjectId = null;
    window.mapLoader = document.querySelector(`#${MAP_LOADER_ID}`);
}

async function initMap() {
    const container = document.querySelector(`#${MAP_CONTAINER_ID}`);

    try {
        if (!container) {
            throw Error(`Не найден элемент c id = ${MAP_CONTAINER_ID}`);
        }

        createInitialState();

        const map = Map();

        const googleSheetsService = new GoogleSheetsService({
            apiKeySheets: API_KEY_SHEETS,
            sheetId: SHEET_ID,
            sheetNumber: 1,
        });
        const parser = new Parser(googleSheetsService);
        const adapter = new Adapter();

        const data = await parser.getData();

        const adaptedData = adapter.adaptData({ categories, data, columns: sheetColumns });
        const collections = adapter.adaptCollections({
            categories,
            objects: adaptedData,
        });
        const categoryNames = adapter.adaptCategoryNames(categories, 'id', 'name');

        MapStore.createInitialState(categories, collections, categoryNames);

        await map.load(MAP_API_KEY);
        await map.create({
            mapContainerID: MAP_CONTAINER_ID,
            mapLoaderID: MAP_LOADER_ID,
            mapBaseParams: MAP_BASE_PARAMS,
        });
    } catch (error) {
        showConsoleError(error);

        const errorMessage = ErrorMessage();

        container.innerHTML = errorMessage.create('Ошибка загрузки карты');
    } finally {
        hideElement(window.mapLoader);
    }
}

document.addEventListener('DOMContentLoaded', initMap);
