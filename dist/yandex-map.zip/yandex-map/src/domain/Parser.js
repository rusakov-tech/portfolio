import { showConsoleError } from '@/utils/showConsoleError';

export class Parser {
    _sourceParser = undefined;

    constructor(sourceParser) {
        this._sourceParser = sourceParser;
    }

    async getData() {
        try {
            const data = await this._sourceParser.getData();

            return data ?? [];
        } catch (error) {
            showConsoleError(error);

            return [];
        }
    }
}
