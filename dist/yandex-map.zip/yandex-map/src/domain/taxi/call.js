export function callTaxi({ from, to }) {
    const currentFrom = from && from.length > 0 ? `&gfrom=${from}` : '';

    window.open(
        `https://taxi.yandex.ru/ru_ru?gto=${to}${currentFrom}`,
        '_blank',
        'noopener, noreferrer'
    );
}
