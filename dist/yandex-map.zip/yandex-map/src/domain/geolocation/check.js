export const checkGeolocation = () => {
    if (!navigator.geolocation) {
        alert('Геолокация не поддерживается');

        return false;
    }

    return true;
};
