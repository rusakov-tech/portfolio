import { showConsoleError } from '@/utils/showConsoleError';

export async function getGeolocationPosition() {
    try {
        const geolocation = await window.ymaps.geolocation.get({
            mapStateAutoApply: true,
            provider: 'yandex',
        });

        return geolocation.geoObjects.position;
    } catch (error) {
        try {
            const geolocation = await window.ymaps.geolocation.get({
                mapStateAutoApply: true,
                provider: 'browser',
            });

            return geolocation.geoObjects.position;
        } catch (error) {
            showConsoleError(error);

            return [];
        }
    }
}
