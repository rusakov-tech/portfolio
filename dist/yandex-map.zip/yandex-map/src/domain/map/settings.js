export const MAP_CONTAINER_ID = 'sk-map';
export const MAP_LOADER_ID = 'sk-map-loader';

export const MAP_CENTER = [55.693_668, 37.349_749];
export const MAP_BASE_ZOOM = 14;
export const MAP_BASE_DURATION_ZOOM = 1000;

export const MAP_BASE_PARAMS = {
    center: MAP_CENTER,
    zoom: MAP_BASE_ZOOM,
    controls: [],
};

export const MAP_PIN_WIDTH = 38;
export const MAP_PIN_HEIGHT = 42;

export const MAP_API_KEY = '9677b0a2-dc79-4bdc-8cb3-a9e0210de256';
