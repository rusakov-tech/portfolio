export class MapStore {
    static categories;

    static collections;

    static categoryNames;

    static setCollections(collections) {
        this.collections = collections;
    }

    static setCategories(categories) {
        this.categories = categories;
    }

    static setCategoryNames(categoryNames) {
        this.categoryNames = categoryNames;
    }

    static createInitialState(categories, collections, categoryNames) {
        this.setCategories(categories);
        this.setCollections(collections);
        this.setCategoryNames(categoryNames);
    }

    static getObjects() {
        return this.collections.flatMap(({ objects }) => objects);
    }
}
