export const categories = [
    {
        id: 'innovation',
        name: 'Где живут инновации',
        objects: [],
    },
    {
        id: 'people',
        name: 'Где живут люди',
        objects: [],
    },
    {
        id: 'art',
        name: 'Искусство',
        objects: [],
    },
    {
        id: 'sport',
        name: 'Спорт',
        objects: [],
    },
    {
        id: 'family',
        name: 'Для всей семьи',
        objects: [],
    },
    {
        id: 'food',
        name: 'Еда',
        objects: [],
    },
    {
        id: 'shops',
        name: 'Магазины',
        objects: [],
    },
    {
        id: 'services',
        name: 'Сервисы',
        objects: [],
    },
    {
        id: 'health-care',
        name: 'Медицинская помощь',
        objects: [],
    },
    {
        id: 'transport',
        name: 'Транспорт',
        objects: [],
    },
    {
        id: 'education',
        name: 'Образование',
        objects: [],
    },
    {
        id: 'zoo',
        name: 'Любимые питомцы',
        objects: [],
    },
];
