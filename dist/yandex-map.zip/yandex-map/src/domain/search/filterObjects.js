export const filterObjects = (objects, value) => {
    const currentValue = value.trim().toLowerCase();

    return objects.filter(cardObject => {
        return (
            cardObject.name.trim().toLowerCase().includes(currentValue) ||
            cardObject.categoryName.trim().toLowerCase().includes(currentValue)
        );
    });
};
