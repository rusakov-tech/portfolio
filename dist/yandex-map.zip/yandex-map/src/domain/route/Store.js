export class RouteStore {
    static route;

    static isActive = false;

    static setRoute(route) {
        this.route = route;
    }

    static removeRoute() {
        this.route = undefined;
    }

    static onIsActive() {
        this.isActive = true;
    }

    static offIsActive() {
        this.isActive = false;
    }
}
