export const sheetColumns = {
    адрес: 'address',
    изображение: 'img',
    категория: 'categoryName',
    координаты: 'coordinates',
    название: 'name',
    описание: 'description',
    'график работы': 'workingHouse',
};
