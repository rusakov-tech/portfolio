import { nanoid } from 'nanoid';

import { showConsoleError } from '@/utils/showConsoleError';

export class Adapter {
    constructor() {}

    adaptCoordinates(value) {
        const match = value.match(/(\d+\.\d+),\s*(\d+\.\d+)/);

        if (match) {
            const firstCoordinates = match[1];
            const secondCoordinates = match[2];

            if (firstCoordinates && secondCoordinates) {
                return [firstCoordinates, secondCoordinates];
            }

            return [];
        }

        return [];
    }

    adaptCategory(categoryNames, value) {
        const match = categoryNames.includes(value);

        if (match) return value;

        showConsoleError(`Неизвестная категория: ${value}`);

        return '';
    }

    adaptWorkingHouse(value) {
        const isCorrect = /(?<!^);(?!$)/.test(value);

        if (isCorrect) return value.replace(';', '<br>');

        return value;
    }

    adaptData({ categories, data, columns }) {
        const adaptedCategoryNames = this.adaptCategoryNames(categories, 'name', 'id');
        const categoryNames = categories.map(({ name }) => name);

        return data.map(item => {
            const newItem = {};

            for (const key in item) {
                const currentKey = columns[key.toLowerCase().trim()];

                if (!currentKey) {
                    continue;
                }

                const value = item[key];
                const clearedValue = value ? value.trim() : '';

                let newValue = clearedValue;

                if (currentKey === 'coordinates') {
                    newValue = this.adaptCoordinates(clearedValue);
                }

                if (currentKey === 'categoryName') {
                    newValue = this.adaptCategory(categoryNames, clearedValue);
                }

                if (currentKey === 'workingHouse') {
                    newValue = this.adaptWorkingHouse(clearedValue);
                }

                newItem[currentKey] = newValue;
            }

            const currentItem = {
                id: nanoid(4),
                categoryId: adaptedCategoryNames[newItem.categoryName],
                ...newItem,
            };

            if (!currentItem.hasOwnProperty('coordinates')) {
                currentItem.coordinates = '';
            }

            if (!currentItem.hasOwnProperty('name')) {
                currentItem.name = '';
            }

            return currentItem;
        });
    }

    adaptCategoryNames(categories, key, keyValue) {
        const categoryNames = {};

        categories.forEach(category => {
            categoryNames[category[key]] = category[keyValue];
        });

        return categoryNames;
    }

    adaptCollections({ categories, objects }) {
        return categories.map(category => ({
            ...category,
            objects: objects.filter(object => object.categoryName === category.name),
        }));
    }
}
