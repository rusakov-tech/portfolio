import { fetchGoogleSheetsData } from 'google-sheets-mapper';
import { showConsoleError } from '@/utils/showConsoleError';

export class GoogleSheetsService {
    sheetNumber = 1;

    _apiKeySheets = '';

    _sheetId = '';

    constructor({ apiKeySheets, sheetId, sheetNumber }) {
        this._apiKeySheets = apiKeySheets;
        this._sheetId = sheetId;
        this.sheetNumber = sheetNumber;
    }

    async getData() {
        try {
            const response = await fetchGoogleSheetsData({
                apiKey: this._apiKeySheets,
                sheetId: this._sheetId,
            });

            return response ? response[this.sheetNumber - 1]?.data : [];
        } catch (error) {
            showConsoleError(error);

            return [];
        }
    }
}
