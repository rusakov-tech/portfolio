import DOMPurify from 'dompurify';

import { baseURL } from '@/domain/baseUrl';

export function Sidebar() {
    return {
        id: 'sk-sidebar',

        create: function ({ header, menu, content }) {
            return DOMPurify.sanitize(/* HTML */ `
                <div class="sk-sidebar" id="${this.id}" data-state="hidden">
                    <div class="sk-sidebar__header-container">
                        <div class="sk-sidebar__header" id="sk-sidebar-header">${header}</div>
                        <button
                            class="sk-sidebar__toggle-visibility sk-btn-reset"
                            id="sk-sidebar-toggle-visibility"
                            type="button"
                            aria-label="Переключить видимость сайдбара"
                        >
                            <img
                                src="${baseURL}/img/lines.svg"
                                width="24"
                                height="24"
                                alt=""
                                aria-hidden="true"
                            />
                        </button>
                    </div>
                    <div class="sk-sidebar__content sk-scrollbar">${menu} ${content}</div>
                </div>
            `);
        },

        addHandlers: function () {
            const sidebar = document.querySelector(`#${this.id}`);
            const sidebarToggleVisibility = sidebar.querySelector('#sk-sidebar-toggle-visibility');

            const handleClick = () => {
                sidebar.dataset.state = sidebar.dataset.state === 'visible' ? 'hidden' : 'visible';
            };

            sidebarToggleVisibility.addEventListener('click', handleClick);
        },
    };
}
