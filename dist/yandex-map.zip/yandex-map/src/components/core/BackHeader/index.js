import DOMPurify from 'dompurify';

import { baseURL } from '@/domain/baseUrl';

export function BackHeader() {
    return {
        id: 'sk-back-header',

        create: function ({ title = '', hidden = true }) {
            return DOMPurify.sanitize(
                /* HTML */ `<div
                    class="sk-back-header ${hidden ? 'sk-visually-hidden' : ''}"
                    id="${this.id}"
                >
                    <button
                        class="sk-back-header__btn-back sk-btn-reset"
                        type="button"
                        aria-label="Вернуться назад"
                        id="sk-back-header-btn-back"
                    >
                        <img
                            class="sk-back-header__btn-back-icon"
                            src="${baseURL}/img/arrow-left.svg"
                            alt=""
                            aria-hidden="true"
                            width="24"
                            height="24"
                        />
                    </button>
                    <div class="sk-back-header__title" id="sk-back-header-title">${title}</div>
                </div>`
            );
        },

        addHandlers: function ({ handleClick }) {
            const categoryHeaderBtnBack = document.querySelector('#sk-back-header-btn-back');

            categoryHeaderBtnBack.addEventListener('click', handleClick);
        },

        getElement: function () {
            return document.querySelector(`#${this.id}`);
        },

        getTitleElement: function () {
            return document.querySelector('#sk-back-header-title');
        },
    };
}
