import DOMPurify from 'dompurify';

export function Menu() {
    return {
        id: 'sk-menu',

        create: function ({ pathToImg, list }) {
            return DOMPurify.sanitize(/* HTML */ `
                <div class="sk-menu" id="${this.id}">
                    ${list
                        .map(function ({ id, name }) {
                            return /* HTML */ `<button
                                class="sk-menu__item sk-btn-reset"
                                data-id="${id}"
                                type="button"
                                aria-label="Открыть категорию"
                            >
                                <img
                                    src="${pathToImg}/${id}.svg"
                                    alt=""
                                    width="24"
                                    height="24"
                                    aria-hidden="true"
                                />
                                ${name}
                            </button>`;
                        })
                        .join('')}
                </div>
            `);
        },

        addHandlers: function ({ additionalHandleClick }) {
            const menuElement = this.getElement();

            const handleClick = event => {
                const clickedElement = event.target;

                if (clickedElement.tagName.toLowerCase() === 'button') {
                    additionalHandleClick(clickedElement.dataset.id);
                }
            };

            menuElement.addEventListener('click', handleClick);
        },

        getElement: function () {
            return document.querySelector(`#${this.id}`);
        },
    };
}
