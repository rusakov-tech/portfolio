import DOMPurify from 'dompurify';

export function ErrorMessage() {
    return {
        create: function (message) {
            return DOMPurify.sanitize(
                /* HTML */ `<div class="sk-error-message" id="sk-error-message">${message}</div>`
            );
        },
    };
}
