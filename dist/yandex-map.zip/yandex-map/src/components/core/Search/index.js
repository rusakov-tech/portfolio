import DOMPurify from 'dompurify';

import { debounce } from '@/utils/debounce';

const DEBOUNCE_DURATION_TIMEOUT = 250; // ms

export function Search() {
    return {
        id: 'sk-search',

        create: function () {
            return DOMPurify.sanitize(/* HTML */ `
                <div class="sk-search" id="${this.id}">
                    <input class="sk-search__input" id="sk-search-input" placeholder="Поиск" />
                    <button
                        class="sk-search__btn sk-btn-reset"
                        id="sk-search-btn"
                        data-state="search"
                        type="button"
                        aria-label="Поиск"
                    />
                </div>
            `);
        },

        addHandlers: function ({ additionalHandleInput, additionalHandleClickBtn }) {
            const searchInput = this.getInput();
            const searchBtn = this.getBtn();

            const setState = hasValue => {
                searchBtn.dataset.state = hasValue ? 'cleaning' : 'search';
            };

            const handleInput = event => {
                const value = event.target.value;

                setState(value.length > 0);

                additionalHandleInput(value);
            };

            const handleClickBtn = () => {
                if (searchBtn.dataset.state === 'search') {
                    searchInput.focus();

                    return;
                }

                setState(false);

                searchInput.value = '';

                additionalHandleClickBtn();
            };

            searchInput.addEventListener('input', debounce(handleInput, DEBOUNCE_DURATION_TIMEOUT));
            searchBtn.addEventListener('click', handleClickBtn);
        },

        getElement: function () {
            return document.querySelector(`#${this.id}`);
        },

        getInput: function () {
            return document.querySelector('#sk-search-input');
        },

        getBtn: function () {
            return document.querySelector('#sk-search-btn');
        },
    };
}
