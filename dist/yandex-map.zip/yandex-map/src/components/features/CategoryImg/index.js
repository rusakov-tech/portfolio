import DOMPurify from 'dompurify';

import { baseURL } from '@/domain/baseUrl';

export function CategoryImg() {
    return {
        create: function (categoryId) {
            return DOMPurify.sanitize(/* HTML */ `
                <img
                    src="${baseURL}/img/categories/${categoryId}.svg"
                    aria-hidden="true"
                    width="20"
                    height="20"
                    alt=""
                />
            `);
        },
    };
}
