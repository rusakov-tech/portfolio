import { CategoryImg } from '@/components/features/CategoryImg';
import { Point } from '@/components/features/Point';
import { baseURL } from '@/domain/baseUrl';
import { MAP_PIN_HEIGHT, MAP_PIN_WIDTH } from '@/domain/map/settings';
import { RouteStore } from '@/domain/route/Store';

export function Route() {
    return {
        create: function ({ id, categoryId, from, to }) {
            const routeView = new window.ymaps.multiRouter.MultiRoute(
                {
                    referencePoints: [from, to],
                    params: {
                        results: 2,
                        routingMode: 'pedestrian',
                    },
                },
                {
                    boundsAutoApply: true,
                    routeStrokeColor: '#4d5759',
                    routeActiveStrokeColor: '#b1ec52',
                    activeRouteAutoSelection: true,
                    pinVisible: false,
                    routeActivePedestrianSegmentStrokeStyle: 'solid',
                    wayPointStartIconImageOffset: [-17.5, -42],
                    wayPointStartIconContentOffset: [9, 8],
                    wayPointStartIconImageSize: [MAP_PIN_WIDTH, MAP_PIN_HEIGHT],
                    wayPointStartIconLayout: 'default#imageWithContent',
                    wayPointStartIconImageHref: `${baseURL}/img/pin-green.svg`,
                    wayPointStartIconContentLayout: window.ymaps.templateLayoutFactory.createClass(
                        Point().create()
                    ),
                    wayPointFinishIconImageOffset: [-17.5, -42],
                    wayPointFinishIconContentOffset: [9, 8],
                    wayPointFinishIconImageSize: [MAP_PIN_WIDTH, MAP_PIN_HEIGHT],
                    wayPointFinishIconLayout: 'default#imageWithContent',
                    wayPointFinishIconImageHref: `${baseURL}/img/pin-green.svg`,
                    wayPointFinishIconContentLayout: window.ymaps.templateLayoutFactory.createClass(
                        CategoryImg().create(categoryId)
                    ),
                }
            );

            window.objectManager.objects.balloon.close(id);

            RouteStore.onIsActive(true);

            return routeView;
        },
    };
}
