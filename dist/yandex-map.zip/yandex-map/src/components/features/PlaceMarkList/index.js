import { baseURL } from '@/domain/baseUrl';

export function PlaceMarkList({ additionalHandleBalloonOpen }) {
    return {
        create: function (featureCollection) {
            window.objectManager.objects.options.set('preset', 'islands#greenDotIcon');
            window.objectManager.clusters.options.set('preset', 'islands#greenClusterIcons');
            window.objectManager.objects.events.add(
                ['mouseenter', 'mouseleave', 'balloonopen', 'balloonclose'],
                event => {
                    const objectId = event.get('objectId');
                    const type = event.get('type');
                    const geometryType =
                        window.objectManager.objects.getById(objectId).geometry.type;

                    if (geometryType !== 'Point') return;

                    if (type === 'balloonclose') {
                        window.objectManager.objects.setObjectOptions(objectId, {
                            iconImageHref: `${baseURL}/img/pin-base.svg`,
                        });
                        window.activeObjectId = null;

                        return;
                    }

                    if (type === 'balloonopen') {
                        window.objectManager.objects.setObjectOptions(objectId, {
                            iconImageHref: `${baseURL}/img/pin-green.svg`,
                        });
                        window.activeObjectId = objectId;

                        const currentObject = featureCollection.features.find(
                            feature => feature.id === objectId
                        );

                        const categoryId = currentObject ? currentObject.properties.categoryId : '';

                        additionalHandleBalloonOpen(categoryId);
                    }

                    if (window.activeObjectId === objectId) return;

                    if (type === 'mouseenter') {
                        window.objectManager.objects.setObjectOptions(objectId, {
                            iconImageHref: `${baseURL}/img/pin-gray.svg`,
                        });

                        return;
                    }

                    if (type === 'mouseleave') {
                        window.objectManager.objects.setObjectOptions(objectId, {
                            iconImageHref: `${baseURL}/img/pin-base.svg`,
                        });
                    }
                }
            );

            window.objectManager.add(featureCollection);
            window.map.geoObjects.add(window.objectManager);
        },
    };
}
