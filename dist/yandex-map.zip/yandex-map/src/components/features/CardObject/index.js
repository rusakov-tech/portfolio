import DOMPurify from 'dompurify';

import { Route } from '@/components/features/Route';
import { baseURL } from '@/domain/baseUrl';
import { checkGeolocation } from '@/domain/geolocation/check';
import { getGeolocationPosition } from '@/domain/geolocation/getPosition';
import { MAP_BASE_DURATION_ZOOM, MAP_BASE_ZOOM } from '@/domain/map/settings';
import { MapStore } from '@/domain/map/Store';
import { RouteStore } from '@/domain/route/Store';
import { callTaxi } from '@/domain/taxi/call';
import { hideElement } from '@/utils/hideElement';
import { showConsoleError } from '@/utils/showConsoleError';
import { showElement } from '@/utils/showElement';

export function CardObject() {
    return {
        create: function ({
            id,
            categoryId,
            name,
            img,
            description,
            address,
            workingHouse,
            coordinates,
            showImg = true,
        }) {
            return DOMPurify.sanitize(/* HTML */ `
                <div
                    data-object
                    class="sk-card-object"
                    data-id="${id}"
                    data-category-id="${categoryId}"
                    data-coordinates="${coordinates}"
                >
                    ${showImg && img
                        ? /* HTML */ `<img
                              class="sk-card-object__img"
                              src="${img}"
                              alt="Изображение объекта"
                              width="287"
                              height="164"
                          />`
                        : ''}
                    <div class="sk-card-object__name" data-object-name>${name || '—'}</div>
                    <div class="sk-card-object__description">${description || '—'}</div>
                    <div class="sk-card-object__contacts">
                        <div class="sk-card-object__contacts-item">
                            <img
                                src="${baseURL}/img/pin-address.svg"
                                alt=""
                                width="16"
                                height="16"
                                aria-hidden="true"
                            />
                            ${address || '—'}
                        </div>
                        <div class="sk-card-object__contacts-item">
                            <img
                                src="${baseURL}/img/calendar.svg"
                                alt=""
                                width="16"
                                height="16"
                                aria-hidden="true"
                            />
                            ${workingHouse || '—'}
                        </div>
                    </div>
                    ${coordinates?.length > 0
                        ? /* HTML */ `
                              <div class="sk-card-object__controls">
                                  <button
                                      data-call-taxi
                                      class="sk-card-object__btn sk-btn-reset"
                                      type="button"
                                  >
                                      <img
                                          src="${baseURL}/img/truck.svg"
                                          alt=""
                                          width="24"
                                          height="24"
                                          aria-hidden="true"
                                      />
                                      Вызвать такси
                                  </button>
                                  <button
                                      data-plan-route
                                      class="sk-card-object__btn sk-btn-reset"
                                      type="button"
                                  >
                                      <img
                                          src="${baseURL}/img/destination.svg"
                                          alt=""
                                          width="24"
                                          height="24"
                                          aria-hidden="true"
                                      />
                                      Проложить маршрут
                                  </button>
                              </div>
                          `
                        : ''}
                </div>
            `);
        },

        handleCallTaxi: async function ({ coordinates }) {
            const isSupportedGeolocation = checkGeolocation();

            if (!isSupportedGeolocation) return;

            const position = await getGeolocationPosition();

            callTaxi({ from: position, to: coordinates });
        },

        handlePlanRoute: async function ({
            id,
            categoryId,
            coordinates,
            additionalHandleRoutePlanning,
        }) {
            const isSupportedGeolocation = checkGeolocation();

            if (!isSupportedGeolocation) return;

            window.mapLoader.dataset.message = 'Построение маршрута';

            showElement(window.mapLoader);

            const position = await getGeolocationPosition();

            if (position.length === 0) return;

            const routeView = Route().create({
                id,
                categoryId,
                from: position,
                to: coordinates,
            });

            window.map.geoObjects.add(routeView);

            routeView.model.events
                .add('requestsuccess', () => {
                    window.objectManager.setFilter(`id === "${id}"`);

                    RouteStore.setRoute(routeView);

                    additionalHandleRoutePlanning({
                        value: name.textContent,
                        objects: MapStore.getObjects(),
                    });

                    hideElement(window.mapLoader);

                    window.mapLoader.dataset.message = '';
                })
                .add('requestfail', showConsoleError);
        },

        checkToggle: async function ({ event, additionalHandleRoutePlanning }) {
            try {
                const clickedElement = event.target;
                const object = clickedElement.closest('[data-object]');

                if (!object) return;

                const name = object.querySelector('[data-object-name]');
                const coordinates = object.dataset.coordinates;
                const id = object.dataset.id;
                const categoryId = object.dataset.categoryId;

                if (clickedElement.dataset.callTaxi !== undefined) {
                    await this.handleCallTaxi({ coordinates });

                    return;
                }

                if (clickedElement.dataset.planRoute !== undefined) {
                    await this.handlePlanRoute({
                        name,
                        additionalHandleRoutePlanning,
                        id,
                        categoryId,
                        coordinates,
                    });

                    return;
                }

                const isMobile = window.matchMedia('(max-width: 1024px)').matches;

                if (isMobile) {
                    document.querySelector('#sk-sidebar').dataset.state = 'hidden';
                }

                if (!coordinates) return;

                window.map
                    .panTo(coordinates.split(',').map(coordinate => parseFloat(coordinate)))
                    .done(() => {
                        window.map.setZoom(MAP_BASE_ZOOM, { duration: MAP_BASE_DURATION_ZOOM });
                        window.objectManager.objects.balloon.open(id);
                    });
            } catch (error) {
                showConsoleError(error);
            }
        },
    };
}
