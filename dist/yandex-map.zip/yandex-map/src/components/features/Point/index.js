import DOMPurify from 'dompurify';

import { baseURL } from '@/domain/baseUrl';

export function Point() {
    return {
        create: function () {
            return DOMPurify.sanitize(
                /* HTML */ `<img
                    src="${baseURL}/img/point.svg"
                    aria-hidden="true"
                    width="20"
                    height="20"
                    alt=""
                />`
            );
        },
    };
}
