import { BalloonLayout } from '@/components/features/BalloonLayout';
import { CategoryImg } from '@/components/features/CategoryImg';
import { baseURL } from '@/domain/baseUrl';
import { MAP_PIN_HEIGHT, MAP_PIN_WIDTH } from '@/domain/map/settings';

export function FeatureCollection() {
    return {
        create: function ({ objects, additionalHandleRoutePlanning, cardObject }) {
            const balloonLayout = BalloonLayout();
            const categoryImg = CategoryImg();

            const balloonLayoutView = balloonLayout.create({ additionalHandleRoutePlanning });

            const ICON_IMAGE_OFFSET_X = -17.5;
            const ICON_IMAGE_OFFSET_Y = -42;
            const ICON_CONTENT_OFFSET_X = 9;
            const ICON_CONTENT_OFFSET_Y = 8;
            const BALLOON_OFFSET_X = -125 - 32;
            const BALLOON_OFFSET_Y = -MAP_PIN_HEIGHT - 3;

            return {
                type: 'FeatureCollection',
                features: objects.map(
                    ({
                        id,
                        coordinates,
                        name,
                        categoryId,
                        img,
                        description,
                        address,
                        workingHouse,
                    }) => ({
                        id,
                        type: 'Feature',
                        geometry: {
                            coordinates,
                            type: 'Point',
                        },
                        properties: {
                            categoryId,
                            balloonContent: cardObject.create({
                                id,
                                categoryId,
                                name,
                                img,
                                description,
                                address,
                                workingHouse,
                                coordinates,
                                showImg: false,
                            }),
                        },
                        options: {
                            iconImageOffset: [ICON_IMAGE_OFFSET_X, ICON_IMAGE_OFFSET_Y],
                            iconContentOffset: [ICON_CONTENT_OFFSET_X, ICON_CONTENT_OFFSET_Y],
                            iconImageSize: [MAP_PIN_WIDTH, MAP_PIN_HEIGHT],
                            balloonPanelMaxMapArea: 0,
                            balloonLayout: balloonLayoutView,
                            balloonShadow: false,
                            hideIconOnBalloonOpen: false,
                            balloonOffset: [BALLOON_OFFSET_X, BALLOON_OFFSET_Y],
                            iconLayout: 'default#imageWithContent',
                            iconImageHref: `${baseURL}/img/pin-base.svg`,
                            iconContentLayout: window.ymaps.templateLayoutFactory.createClass(
                                categoryImg.create(categoryId)
                            ),
                        },
                    })
                ),
            };
        },
    };
}
