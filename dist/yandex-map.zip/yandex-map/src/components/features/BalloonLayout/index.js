import DOMPurify from 'dompurify';

import { CardObject } from '@/components/features/CardObject';
import { baseURL } from '@/domain/baseUrl';
import { showConsoleError } from '@/utils/showConsoleError';

const OFFSET = 30;

export function BalloonLayout() {
    return {
        create: function ({ additionalHandleRoutePlanning }) {
            const balloonLayout = window.ymaps.templateLayoutFactory.createClass(
                DOMPurify.sanitize(
                    /* HTML */ `<div class="sk-balloon-layout" id="sk-balloon-layout">
                        <button
                            class="sk-balloon-layout-btn-close sk-btn-reset"
                            type="button"
                            aria-label="Закрыть карточку объекта"
                            id="sk-balloon-layout-btn-close"
                        >
                            <img
                                src="${baseURL}/img/cross.svg"
                                alt=""
                                aria-hidden="true"
                                width="24"
                                height="24"
                            />
                        </button>
                        $[properties.balloonContent]
                    </div>`
                ),
                {
                    build: function () {
                        this.constructor.superclass.build.call(this);

                        this._balloonLayout =
                            this.getParentElement().querySelector('#sk-balloon-layout');
                        this._btnClose = this._balloonLayout.querySelector(
                            '#sk-balloon-layout-btn-close'
                        );

                        this._btnClose.addEventListener('click', this.onCloseClick.bind(this));
                        this._balloonLayout.addEventListener('click', async event => {
                            try {
                                await CardObject().checkToggle({
                                    event,
                                    additionalHandleRoutePlanning,
                                });
                            } catch (error) {
                                showConsoleError();
                            }
                        });

                        this.applyElementOffset();
                    },

                    clear: function () {
                        this._btnClose.removeEventListener('click', this.onCloseClick.bind(this));

                        this.constructor.superclass.clear.call(this);
                    },

                    onSublayoutSizeChange: function () {
                        this._balloonLayout.superclass.onSublayoutSizeChange.apply(this, arguments);

                        if (!this._isElement(this._balloonLayout)) return;

                        this.applyElementOffset();

                        this.events.fire('shapechange');
                    },

                    applyElementOffset: function () {
                        this._balloonLayout.style.left = `${-(this._balloonLayout.offsetWidth / 2)}px`;
                        this._balloonLayout.style.top = `${-this._balloonLayout.offsetHeight}px`;
                    },

                    onCloseClick: function (event) {
                        event.preventDefault();

                        this.events.fire('userclose');
                    },

                    getShape: function () {
                        if (!this._isElement(this._balloonLayout)) {
                            return balloonLayout.superclass.getShape.call(this);
                        }

                        const top = this._balloonLayout.offsetTop;
                        const left = this._balloonLayout.offsetLeft;

                        return new window.ymaps.shape.Rectangle(
                            new window.ymaps.geometry.pixel.Rectangle([
                                [left + OFFSET, top],
                                [
                                    left + this._balloonLayout.offsetWidth + OFFSET,
                                    top +
                                        this._balloonLayout.offsetHeight +
                                        this._btnClose.offsetHeight,
                                ],
                            ])
                        );
                    },

                    _isElement: function (element) {
                        return element && element.querySelector('#sk-balloon-layout-btn-close');
                    },
                }
            );

            return balloonLayout;
        },
    };
}
