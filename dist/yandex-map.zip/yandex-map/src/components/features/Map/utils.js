import { filterObjects } from '@/domain/search/filterObjects';
import { hideElement } from '@/utils/hideElement';
import { showElement } from '@/utils/showElement';

export const openMenu = ({
    backHeaderElement,
    objectListElement,
    searchElement,
    menuElement,
    backHeaderTitleElement,
}) => {
    hideElement(backHeaderElement);
    hideElement(objectListElement);

    showElement(searchElement);
    showElement(menuElement);

    backHeaderTitleElement.textContent = '';
    objectListElement.innerHTML = '';
};

export const openCategory = ({
    currentCollection,
    backHeaderTitleElement,
    searchElement,
    objectListElement,
    cardObject,
    menuElement,
    backHeaderElement,
    backHeaderTitleValue,
}) => {
    backHeaderTitleElement.textContent = backHeaderTitleValue;

    const hasCurrentCollection = currentCollection && currentCollection.objects.length > 0;

    objectListElement.innerHTML = hasCurrentCollection
        ? currentCollection.objects.map(cardObject.create).join('')
        : 'Объекты не найдены';

    hideElement(searchElement);
    hideElement(menuElement);

    showElement(backHeaderElement);
    showElement(objectListElement);
};

export const toggleObjectList = ({
    value,
    menuElement,
    objectListElement,
    objects,
    cardObject,
}) => {
    if (!value || value?.length === 0) {
        showElement(menuElement);

        hideElement(objectListElement);

        objectListElement.innerHTML = '';

        window.objectManager.setFilter(false);

        return;
    }

    const filteredObjects = filterObjects(objects, value);
    const hasFilteredObjects = filteredObjects && filteredObjects.length > 0;

    objectListElement.innerHTML = hasFilteredObjects
        ? filteredObjects.map(cardObject.create).join('')
        : 'Объекты не найдены';

    hideElement(menuElement);

    showElement(objectListElement);
};

export const switchViewForRoutePlanning = ({
    search,
    backHeaderElement,
    searchElement,
    menuElement,
    backHeaderTitleElement,
    cardObject,
    objects,
    objectListElement,
    value,
}) => {
    search.getInput().value = value;
    search.getBtn().dataset.state = 'cleaning';

    hideElement(backHeaderElement);

    showElement(searchElement);
    showElement(menuElement);

    backHeaderTitleElement.textContent = '';

    toggleObjectList({
        menuElement,
        cardObject,
        objects,
        objectListElement,
        value,
    });
};
