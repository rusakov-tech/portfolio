import { MapSidebar } from '@/components/features/Map/Sidebar';
import { showConsoleError } from '@/utils/showConsoleError';

export function Map() {
    return {
        load: async mapApiKey => {
            return new Promise((resolve, reject) => {
                const script = document.createElement('script');

                script.src = `https://api-maps.yandex.ru/2.1/?load=package.standard&lang=ru-RU&apikey=${mapApiKey}`;
                script.addEventListener('load', resolve);
                script.onerror = reject;

                document.head.append(script);
            });
        },

        create: async function ({ mapContainerID, mapBaseParams }) {
            try {
                await window.ymaps.ready();

                window.map = new window.ymaps.Map(mapContainerID, mapBaseParams);
                window.objectManager = new window.ymaps.ObjectManager({
                    clusterize: false,
                    gridSize: 32,
                    clusterDisableClickZoom: true,
                });

                await MapSidebar().create();
            } catch (error) {
                showConsoleError(error);
            }
        },
    };
}
