import { BackHeader } from '@/components/core/BackHeader';
import { Menu } from '@/components/core/Menu';
import { Search } from '@/components/core/Search';
import { Sidebar } from '@/components/core/Sidebar';
import { CardObject } from '@/components/features/CardObject';
import { FeatureCollection } from '@/components/features/FeatureCollection';
import {
    openCategory,
    openMenu,
    switchViewForRoutePlanning,
    toggleObjectList,
} from '@/components/features/Map/utils';
import { ObjectList } from '@/components/features/ObjectList';
import { PlaceMarkList } from '@/components/features/PlaceMarkList';
import { baseURL } from '@/domain/baseUrl';
import { MAP_BASE_DURATION_ZOOM, MAP_BASE_ZOOM } from '@/domain/map/settings';
import { MapStore } from '@/domain/map/Store';
import { RouteStore } from '@/domain/route/Store';
import { filterObjects } from '@/domain/search/filterObjects';
import { hideElement } from '@/utils/hideElement';
import { showConsoleError } from '@/utils/showConsoleError';
import { showElement } from '@/utils/showElement';

export function MapSidebar() {
    const sidebar = Sidebar();
    const search = Search();
    const backHeader = BackHeader();
    const menu = Menu();
    const objectList = ObjectList();
    const cardObject = CardObject();

    return {
        create: async function () {
            try {
                window.ymaps.modules.define(
                    'MapSidebar',
                    ['util.augment', 'collection.Item'],
                    function (provide, augment, item) {
                        const MapSidebar = function (options) {
                            MapSidebar.superclass.constructor.call(this, options);
                        };

                        augment(MapSidebar, item, {
                            onAddToMap: function (map) {
                                MapSidebar.superclass.onAddToMap.call(this, map);

                                this.getParent()
                                    .getChildElement(this)
                                    .then(this._onGetChildElement.bind(this));
                            },

                            onRemoveFromMap: function (oldMap) {
                                if (this._sidebarView) {
                                    this._sidebarView.remove();
                                }

                                MapSidebar.superclass.onRemoveFromMap.call(this, oldMap);
                            },

                            _onGetChildElement: function (parentDomContainer) {
                                this._sidebarView = document.createElement('div');
                                this._sidebarView.classList.add('customControl');
                                this._sidebarView.innerHTML = sidebar.create({
                                    menu: menu.create({
                                        pathToImg: `${baseURL}/img/categories`,
                                        list: MapStore.categories,
                                    }),
                                    header: `${search.create()} ${backHeader.create({})}`,
                                    content: objectList.create([]),
                                });

                                parentDomContainer.appendChild(this._sidebarView);
                            },
                        });

                        provide(MapSidebar);
                    }
                );

                window.ymaps
                    .ready(['MapSidebar'])
                    .then(() => {
                        window.map.controls.add(new window.ymaps.MapSidebar());
                    })
                    .done(() => {
                        const searchElement = search.getElement();
                        const backHeaderElement = backHeader.getElement();
                        const menuElement = menu.getElement();
                        const objectListElement = objectList.getElement();
                        const backHeaderTitleElement = backHeader.getTitleElement();

                        const objects = MapStore.getObjects();

                        sidebar.addHandlers();
                        search.addHandlers({
                            additionalHandleInput: value => {
                                toggleObjectList({
                                    value,
                                    menuElement,
                                    cardObject,
                                    objects,
                                    objectListElement,
                                });

                                const filteredObjects = filterObjects(objects, value);
                                const hasFilteredObjects =
                                    filteredObjects && filteredObjects.length > 0;

                                const categoryId = hasFilteredObjects
                                    ? filteredObjects[0].categoryId
                                    : '';

                                if (categoryId) {
                                    window.objectManager.setFilter(
                                        `properties.categoryId === "${categoryId}"`
                                    );

                                    return;
                                }

                                window.objectManager.setFilter(false);
                            },
                            additionalHandleClickBtn: () => {
                                showElement(menuElement);
                                hideElement(objectListElement);

                                objectListElement.innerHTML = '';

                                window.objectManager.setFilter(false);
                                window.map.geoObjects.remove(RouteStore.route);

                                RouteStore.removeRoute();
                                RouteStore.offIsActive();

                                window.map.panTo(MAP_CENTER).done(() => {
                                    window.map.setZoom(MAP_BASE_ZOOM, {
                                        duration: MAP_BASE_DURATION_ZOOM,
                                    });
                                });
                            },
                        });
                        backHeader.addHandlers({
                            handleClick: () => {
                                openMenu({
                                    searchElement,
                                    backHeaderElement,
                                    backHeaderTitleElement,
                                    menuElement,
                                    objectListElement,
                                });

                                window.objectManager.setFilter(false);
                            },
                        });
                        menu.addHandlers({
                            additionalHandleClick: id => {
                                const currentCollection = MapStore.collections.find(
                                    collection => collection.id === id
                                );

                                openCategory({
                                    id,
                                    cardObject,
                                    menuElement,
                                    backHeaderTitleElement,
                                    backHeaderElement,
                                    searchElement,
                                    objectListElement,
                                    currentCollection,
                                    backHeaderTitleValue: MapStore.categoryNames[id],
                                });

                                window.objectManager.setFilter(`properties.categoryId === "${id}"`);
                            },
                        });
                        objectList.addHandlers({
                            additionalHandleClick: async event => {
                                try {
                                    await cardObject.checkToggle({
                                        event,
                                        additionalHandleRoutePlanning: ({ value }) => {
                                            switchViewForRoutePlanning({
                                                searchElement,
                                                backHeaderElement,
                                                backHeaderTitleElement,
                                                cardObject,
                                                value,
                                                menuElement,
                                                objectListElement,
                                                objects,
                                                search,
                                            });
                                        },
                                    });
                                } catch (error) {
                                    showConsoleError(error);
                                }
                            },
                        });

                        PlaceMarkList({
                            additionalHandleBalloonOpen: id => {
                                openCategory({
                                    cardObject,
                                    menuElement,
                                    backHeaderTitleElement,
                                    backHeaderElement,
                                    searchElement,
                                    objectListElement,
                                    currentCollection: MapStore.collections.find(
                                        collection => collection.id === id
                                    ),
                                    backHeaderTitleValue: MapStore.categoryNames[id],
                                });

                                window.objectManager.setFilter(`properties.categoryId === "${id}"`);
                            },
                        }).create(
                            FeatureCollection().create({
                                objects,
                                cardObject,
                                additionalHandleRoutePlanning: ({ value }) => {
                                    switchViewForRoutePlanning({
                                        searchElement,
                                        backHeaderElement,
                                        backHeaderTitleElement,
                                        cardObject,
                                        value,
                                        menuElement,
                                        objectListElement,
                                        objects,
                                        search,
                                    });
                                },
                            })
                        );
                    });
            } catch (error) {
                showConsoleError(error);
            }
        },
    };
}
