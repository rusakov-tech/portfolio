import DOMPurify from 'dompurify';

import { CardObject } from '@/components/features/CardObject';
import { showConsoleError } from '@/utils/showConsoleError';

export function ObjectList() {
    return {
        id: 'sk-object-list',

        create: function (objects) {
            const hasObjects = objects && objects.length > 0;

            return DOMPurify.sanitize(
                /* HTML */ `<div
                    class="sk-object-list ${hasObjects ? '' : 'sk-visually-hidden'}"
                    id="${this.id}"
                >
                    ${hasObjects ? objects.map(CardObject().create).join('') : ''}
                </div>`
            );
        },

        addHandlers: function ({ additionalHandleClick }) {
            const handleClick = async event => {
                try {
                    await additionalHandleClick(event);
                } catch (error) {
                    showConsoleError(error);
                }
            };

            this.getElement().addEventListener('click', handleClick);
        },

        getElement: function () {
            return document.querySelector(`#${this.id}`);
        },
    };
}
