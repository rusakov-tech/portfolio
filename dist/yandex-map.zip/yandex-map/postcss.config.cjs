module.exports = {
    plugins: {
        autoprefixer: {},
        'postcss-custom-media': {},
        ...(process.env.NODE_ENV === 'production' ? { cssnano: {} } : {}),
    },
};
